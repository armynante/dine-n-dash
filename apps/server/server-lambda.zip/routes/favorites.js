"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-nocheck
const express_1 = require("express");
const db_1 = __importDefault(require("../db"));
const diner_utilities_1 = require("diner-utilities");
const router = (0, express_1.Router)();
router.get('/', diner_utilities_1.verifyToken, async (req, res) => {
    try {
        const { data, error } = await db_1.default.from('favorites').select();
        if (error) {
            throw error;
        }
        res.status(200).json(data);
    }
    catch (error) {
        console.error(error);
        res.status(500).json(error);
    }
});
router.post('/', diner_utilities_1.verifyToken, async (req, res) => {
    console.log('Creating favorite');
    try {
        const { name, site, siteData } = req.body;
        const { data, error } = await db_1.default
            .from('favorites')
            .insert([{ name, site, siteData }])
            .select()
            .single();
        if (error) {
            throw error;
        }
        res.status(201).json(data);
    }
    catch (error) {
        console.error(error);
        res.status(500).json(error);
    }
});
exports.default = router;
