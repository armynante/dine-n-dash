declare const router: Router;
export default router;
