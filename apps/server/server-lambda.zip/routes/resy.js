"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-nocheck
const express_1 = require("express");
const db_1 = __importDefault(require("../db"));
const diner_resy_1 = require("diner-resy");
const diner_utilities_1 = require("diner-utilities");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const secretKey = process.env.JWT_SECRET;
if (!secretKey) {
    throw new Error('Missing JWT_SECRET environment variable');
}
/*
 * ########################################
 * #######  RESY INITIALIZATION    ########
 * ########################################
 */
const agent = (0, diner_utilities_1.ProxyAgent)({
    host: process.env.PROXY_HOST,
    port: parseInt(process.env.PROXY_PORT),
    username: process.env.PROXY_USERNAME,
    password: process.env.PROXY_PASSWORD,
});
const RESY_API_KEY = 'ResyAPI api_key="AIcdK2rLXG6TYwJseSbmrBAy3RP81ocd"';
const Resy = new diner_resy_1.ResyService(agent, RESY_API_KEY);
const router = (0, express_1.Router)();
router.post('/login', diner_utilities_1.verifyToken, async (req, res) => {
    console.log('Logging in with Resy auth...');
    try {
        const { email, password } = req.body;
        const { token: user } = req;
        const resyUser = await Resy.login(email, password);
        const updatedUser = await db_1.default.updateUser(user, {
            resyLegacyToken: resyUser.resyLegacyToken,
            resyToken: resyUser.resyToken,
            resyRefreshToken: resyUser.resyRefreshToken,
            resyPaymentMethodId: resyUser.resyPaymentMethodId,
            resyGuestId: resyUser.resyGuestId,
            resyId: resyUser.resyId,
            resyEmail: resyUser.resyEmail,
        });
        console.log('User updated');
        const token = jsonwebtoken_1.default.sign(updatedUser, secretKey, { expiresIn: '365d' });
        res.status(200).send(token);
    }
    catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
});
router.get('/search', diner_utilities_1.verifyToken, async (req, res) => {
    try {
        const { venueName } = req.query;
        const { token: user } = req;
        console.log(`Searching for ${venueName}`);
        const venues = await Resy.searchVenues(user, venueName);
        res.status(200).send(venues);
    }
    catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
});
router.get('/seatings', diner_utilities_1.verifyToken, async (req, res) => {
    try {
        const { startTime, endTime, venue, partySize, day } = req.body;
        const { token: user } = req;
        const query = {
            startTime,
            endTime,
            venue,
            day,
            partySize,
            user: user,
        };
        const seatings = await Resy.seatings(query);
        res.status(200).send(seatings);
    }
    catch (error) {
        console.error(error);
        res.status(500).send(error);
    }
});
router.post('/book', diner_utilities_1.verifyToken, async (req, res) => {
    try {
        const { slot } = req.body;
        const { token: user } = req;
        const bookingRequest = await Resy.requestBooking({
            config_id: slot.bookingData.config_id,
            party_size: slot.partySize,
            day: slot.dateTime,
            user: user,
        });
        // sleep 5 seconds        // await sleep(5000);
        const { data: confirmed } = await Resy.confirmBooking({
            user: user,
            book_token: bookingRequest.bookToken
        });
        res.status(200).json(confirmed);
    }
    catch (error) {
        // console.error(error);
        res.status(500).json(error);
    }
});
exports.default = router;
