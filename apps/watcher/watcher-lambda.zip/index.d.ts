import { SQSEvent } from 'aws-lambda';
export declare const handler: (event: SQSEvent) => Promise<void>;
//# sourceMappingURL=index.d.ts.map