import { DevWorker, Types, Worker } from 'diner-utilities';
export declare const runWorker: (watcherConfig: Types.Watcher, jobID: string | number, WatcherQueue: Worker | DevWorker) => Promise<void>;
//# sourceMappingURL=worker.d.ts.map