import { DevWorker, Types } from 'diner-utilities';
import { Worker } from 'diner-utilities';
export declare const updateWatcherId: (config: Types.Watcher, jobId: string | number) => Promise<Types.Watcher>;
export declare const resetFailures: (config: Types.Watcher, WatcherQueue: Worker | DevWorker) => Promise<void>;
export declare const markCompleteIfToday: (config: Types.Watcher, WatcherQueue: Worker | DevWorker) => Promise<void>;
export declare const seatingCheck: (config: Types.Watcher, WatcherQueue: Worker | DevWorker) => Promise<false | Types.SeatingResponse>;
export declare const bookSeating: (seatings: Types.SeatingResponse, config: Types.Watcher) => Promise<void>;
export declare const updateWatcherWithErrors: (config: Types.Watcher, jobError: unknown, WatcherQueue: Worker | DevWorker) => Promise<void>;
//# sourceMappingURL=helpers.d.ts.map